#include "pch.h"
#include "Person.h"
#include <string>
#include <map>
#include <iostream>
#include <utility>
#include <functional>
#include <set>
#include <algorithm>

using namespace std;


Person::Person()
{
}


Person::~Person()
{
}

void Person::print() const
{
	cout << name << ": " << age << endl;
}

void Person::getValues()
{

	for (map<int, Person>::iterator it = people.begin(); it != people.end(); it++)
	{
		it->second.print();
	}
}

void Person::insertValues()
{
	cout << "Insert the person's name: ";
	cin >> name;
	cout << "\nInsert the person's age: ";
	cin >> age;

	//insert the valeus into the map
	people.insert(make_pair(age, Person(name, age)));
}

