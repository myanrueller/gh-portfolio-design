#pragma once
#include <string>
#include <map>

using namespace std;

class Person
{
private:
	string name;
	int age;

public:
	Person();
	~Person();

	Person(string name, int age) : name(name), age(age) {

	}


	//Functions for the program
	void print() const; //templating for printing values

	void getValues(); //checks and prints current values
	void insertValues(); //adds values


	map <int, Person> people;
};

