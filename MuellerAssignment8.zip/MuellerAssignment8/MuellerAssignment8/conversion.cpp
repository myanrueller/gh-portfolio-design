#include "stdafx.h"
#include "conversion.h"
#include <iostream>
#include <limits>
#include <exception>

using namespace std;


conversion::conversion()
{

}


conversion::~conversion()
{
}

void conversion::userInput()
{
	do
	{
		displayMenu();

		cin >> menuChoice;
		switch (menuChoice)
		{
		case 1:
			//have the user enter data for farenheit to be converted
			cout << "Enter the temperature in farenheit: ";
			checkForLetters();

			convertedTemp = (userTemp - 32) * 5 / 9;
			printTemp();

			break;

		case 2:
			//have the user enter data for celsius to be converted
			cout << "Enter the temperature in Celsius: ";
			checkForLetters();
			convertedTemp = userTemp * 9 / 5 + 32;
			printTemp();

			break;

		default:
			//show the user that the choice entered is invalid

			cout << "That is an invalid menu choice. Please try again.";
			break;
		}

	} while (menuChoice != 3);
}

void conversion::printTemp()
{
	cout << "The new temperature after your conversion is: " << convertedTemp << " degrees.\n";
}

void conversion::displayMenu()
{
	cout << "What would you like to convert?\n\n"
		<< "1 - Farenheit to celsius\n"
		<< "2 - Celsius to Farenheit\n"
		<< "3 - Exit the Program\n";
}

void conversion::checkForLetters()
{
	try
	{
		cin >> userTemp;

		if (userTemp)
		{
			throw alphaNum;
		}
	}


	catch (char alphaNum)
	{
		cin.clear();
		cout << "Error, line #72, values must be numeric." << endl;
		cout << "Enter a new temp: ";
		cin >> userTemp;
	}
}