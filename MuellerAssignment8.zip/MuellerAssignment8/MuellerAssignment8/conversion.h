#pragma once
#include <iostream>

using namespace std;
class conversion
{
public:
	conversion();
	~conversion();
	//Constructor and destructor for class

	void userInput();
	void printTemp();
	void displayMenu();
	//class functions to convert the function.

private:
	double userTemp;
	double convertedTemp;
	int menuChoice;


	void checkForLetters();
	const char alphaNum[26] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
	'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

};

