#pragma once
#include <string>
class conversion
{
public:
	double feet; //variables within the class, so that the declarations are easy to follow.
	double inches;
	double pounds;
	double kiloGrams;
	double centimeters;

	/*Prototype Functions. The prototypes are within the class, but the declaration for the function are declared outside the class for
	space and readability*/

	void cmToFeet();
	void cmToInches();
	void feetToCm();

	void kgToPounds();
	void lbsToKilograms();

};

class name
{
protected:
	/*I found that the compiler was expecting int to be in protected.
	I used protected strings because I found that subclasses could use the data and store them with this type.*/
	std::string firstName; 
	std::string lastName;
public:
	void printUser();
};

class user : public name
{
public:
	void getUser();
};