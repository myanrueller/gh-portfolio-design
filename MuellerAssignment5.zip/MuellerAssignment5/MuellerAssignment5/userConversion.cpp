#include "stdafx.h"
#include "userConversion.h"


#include <iostream>
#include <cmath>
#include <string>

using namespace std;

void conversion::cmToFeet()
{
	cout << "Okay. Enter the length in centimeters:  ";
	cin >> centimeters;
	feet = remainder(centimeters, 30.48);
	cout << feet << " feet " << "is equal  to " << centimeters << " centimeters in length. \n\n";
}

void conversion::cmToInches()
{
	cout << "Okay. Enter the length in centimeters: ";
	cin >> centimeters;
	inches = (centimeters / 30.48) / 2.54;
	cout << inches << " inches is equal to " << centimeters << " centimeters in length. \n\n";
}

void conversion::feetToCm() {
	cout << "Okay. Enter the feet: ";
	cin >> feet;
	cout << "\nEnter the inches: ";
	cout << inches;

	centimeters = (feet * 30.48) + (inches * 2.54);
	cout << centimeters << " centimeters is equal to " << feet << " feet and " << inches << " inches.\n\n ";
}

void conversion::lbsToKilograms()
{
	cout << "Okay. Enter the pounds: ";
	cin >> pounds;
	kiloGrams = pounds * 0.45359;
	cout << kiloGrams << " kilograms is equal to " << pounds << " pounds.\n\n";
}

void conversion::kgToPounds()
{
	cout << "Okay. Enter the kilograms: ";
	cin >> kiloGrams;

	pounds = kiloGrams / 0.45359;
	cout << pounds << " pounds is equal to " << kiloGrams << " kilograms.\n\n";
}

void name::printUser()
{
	cout << firstName << " " << lastName << ".\n\n";
}

void user::getUser()
{
	cout << "Enter your first name:  ";
	cin >> firstName;
	cout << "Enter your last name:  ";
	cin >> lastName;
}